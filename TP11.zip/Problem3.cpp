#include<iostream>
using namespace std;
struct Element{
  string value;
  Element *next;
};
struct List{
  int n;//size
  Element *head,*tail;//pointer
};
List *EmptyList(){
  List *ls;
  ls = new List();
  ls->head = NULL;
  ls->tail = NULL;
  return ls;
}
const int SIZE=10;// const it mean cannot change
List *ht[SIZE];

void CreateArrayOfList(){
  for(int i=0;i<SIZE;i++){
    ht[i]=EmptyList();
  }
}

void addToEnd(List *ls, string name){
  Element *e = new Element();
  e->value = name;
  e->next = NULL;
  
  if(ls->n == 0){
    ls->head = ls->tail = e;
  }
  else{
    ls->tail->next = e;
    ls->tail = e;
  }
}
int hashFunction(int key){
  return key %SIZE;
}
void Insert(string name){
  int sum = 0;
  for(int i=0;i<name.length();i++){
    sum = sum + static_cast<int> (name[i]) ;
  }
  int index = hashFunction(sum);
  addToEnd(ht[index],name);
}
void display(){
  Element *tmp;
  for(int i=0;i<SIZE;i++){
    
    cout<<i<<" ---> ";
    if(ht[i]!=NULL){
      tmp = ht[i]->head;
      while(tmp != NULL){
        cout<<tmp->value<<" ";
        tmp = tmp->next;
      }
    }
    cout<<"\n";
  }
}

void Search(string name){
  int sum = 0;
  for(int i=0;i<name.length();i++){
    sum = sum + static_cast<int> (name[i]) ;
  }
  int index = hashFunction(sum);
  Element *tmp = ht[index]->head;
  bool check = 0;
  while(tmp != NULL){
    if(name == tmp->value){
      cout<<tmp->value<<" is containted in index "<<index<<endl;
      check = 1;  
    }
    tmp = tmp->next;
  }
  if(check == 0){
    cout<< "Not found"<<endl;
  }
}

void remove(int value){
  int index = hashFunction(value);
  Element *tmp = ht[index]->head;
  cout<<tmp->value<<" Deleted"<<endl;
  ht[index]->head = ht[index]->head->next;
  delete tmp;
}

int main(){
  CreateArrayOfList();
  Insert("Bob");
  Insert("Jane");
  display();
  
}
