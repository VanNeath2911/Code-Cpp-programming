#include<iostream>
using namespace std;
struct Element{
    int value;
    Element *next;
};
struct List{
    int n;
    Element *head;
    Element *tail;
};
List *createEmptylist(){
    List *e;
    e = new List();
    e -> n = 0;
    e -> head = NULL;
    e -> tail = NULL;
    return e;
}
const int SIZE = 7;
List *ht[SIZE];

void CreateArrayOflist(){
    for(int i=0; i<SIZE; i++){
        ht[i] = createEmptylist();
    }
}

void addToEnd(List *ls, int value){
    Element *e = new Element();
    e -> value = value;
    e -> next = NULL;
    if(ls -> n ==0){
        ls -> head = ls -> tail = e;
    }else{
        ls -> tail -> next  = e;
        ls -> tail = e;
    }
    ls -> n++;
}
int hashFunction(int key){
    return key % SIZE;
}
void Insert(int value){
    int index = hashFunction(value);
    addToEnd(ht[index], value);
}

void display(){
    Element *tmp;
    for(int i = 0; i < SIZE; i++){
        cout << i << "-->";
        if(ht[i] != NULL){
            tmp = ht[i] -> head;
            while(tmp != NULL){
                cout << tmp -> value << " ";
                tmp = tmp -> next; 
            }
        }
        cout << endl;
    }
}
void search(int value){
    int index = hashFunction(value);
    Element *tmp = ht[index] -> head;
    bool check = 0;
    while(tmp != NULL){
        if(value == tmp -> value){
            cout << tmp -> value << "is contained in "<< tmp -> value << endl;
            check = 1;
        }
        tmp = tmp -> next;
    }
    if(check == 0){
        cout << "Not found" << endl;
    }
}
void remove(int value){
    int index = hashFunction(value);
    Element *tmp = ht[index] -> head;
    cout << tmp -> value << "deleted" << endl;
    ht[index] -> head = ht[index] -> head -> next;
    delete tmp;
}
int main(){
    CreateArrayOflist();
    Insert(2);
    Insert(4);
    Insert(7);
    Insert(10);
    display();
    cout << endl << "After delete" << endl;
    remove(10);
    display();
}
