#include<iostream>
using namespace std;
struct Element{
    string name;
    string ID;
    Element *next;
};
struct List{
    int n;
    Element *head;
    Element *tail;
};
List *createList(){
    List *mylist;
    mylist = new List;

    mylist->n = 0;
    mylist->head = NULL;
    mylist->tail = NULL;

    return mylist;
}
const int SIZE = 10;
List *ht[SIZE];
void createEmptylist(){
    for(int i = 0;i<SIZE;i++){
        ht[i] = createList();
    }
}
void addToEnd(List *mylist, string newData,string newID){
    Element *e;
    e = new Element;
    e->name = newData;
    e->ID = newID;
    e->next = NULL;

    if(mylist->n == 0){ //when list is empty
        mylist->head = e;
        mylist->tail = e;
        mylist->n = mylist->n + 1;
    }else{ //when list is not empty
        mylist->tail->next = e; //link connection
        mylist->tail = e; //update variable tail
        mylist->n = mylist->n + 1;
    }
}
int hashFunction(string name,string ID){
    int  sum = 0;
    for(int i=0;i<name.size();i++){
        sum = sum + name[i];
    }
    return sum % SIZE;
}
void Insert(string name,string ID){
    int index = hashFunction(ID,name);
    addToEnd(ht[index],ID,name);
}
void displayList(){
    Element *t;
    for(int i=0;i<SIZE;i++){
        cout<<i<<"-->";
        if(ht[i]!=NULL){
            t = ht[i]->head;
            while(t!=NULL){
                cout<<t->ID<<"\t"<<t->name<<" ";
                t=t->next;
            }
            cout<<endl;
        }
    }
}
void search(string name,string ID){
    int index = hashFunction(ID,name);
    Element *tmp = ht[index]->head;
    bool check = 0;
    while(tmp!=NULL){
        if(name == tmp -> name){
            cout<<tmp->ID<<"\t"<<tmp->ID<<" is contian in index"<<index<<endl;
            check = 1;
        }
        tmp = tmp->next;
    }
    if(check == 0){
        cout<<"Not found"<<endl;
    }
}
void remove(string name,string ID){
    int index = hashFunction(name,ID);
    Element *tmp = ht[index]->head;
    cout<<tmp->ID<<"\t"<<tmp->name<<"Deleted"<<endl;
    ht[index]->head = ht[index]->head->next;
    delete tmp;
}
int main(){
    List *e;
    createEmptylist();
    Insert("e20221270","Deth Rathanak");
    Insert("e20220208","An Vanneath");
    Insert("e20220483","Heng Tykea");
    displayList();
    
}