#include<iostream>
using namespace std;

struct Element{
    int data;
    Element *next;
};

struct ListElement{
    int n;
    Element *head;
    Element *tail;
};

int main(){
}