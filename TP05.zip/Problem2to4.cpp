#include<iostream>
using namespace std;
struct student{
    int ID;
    string name;
    int year;
    string program;
    student *link;
};

struct Liststudent{
    int n;
    student *head;
    student *tail;
};
Liststudent* createEmptyList(){
    Liststudent *z;
    z = new Liststudent();
    z -> n = 0;
    z -> head = NULL;
    z -> tail = NULL;

    return z;
}
void add(student s, Liststudent *z){
    student *new_student = new student();
    // Data
    new_student -> ID = s.ID;
    new_student -> name = s.name;
    new_student -> year = s.year;
    new_student -> program = s.program;

    //Link
    new_student -> link = z -> head;
    z -> head = new_student;
}
void display(Liststudent *z){
    student *tmp;

    tmp = z -> head;
    while(tmp != NULL){
        cout << "\n****Student****" << endl;
        cout<< "ID: " << tmp -> ID <<endl;
        cout<< "Name: " << tmp -> name <<endl;
        cout<< "Year: "<< tmp -> year <<endl;
        cout<< "Program: " << tmp -> program <<endl;
        tmp = tmp -> link;
    }

}
int main(){
    Liststudent *y;
    y = createEmptyList();

    // char choice;
    // cout << "Enter your choice: ";
    // cin >> choice;

    // switch(choice){
    //     case 'A':
    //     cout << "Enter your ID: ";
    //     cin >> ID;

    //     add(y, z)
    // }

    student s1, s2, s3, s4, s5;
    s1.ID = 123;
    s1.name = "Chantha";
    s1.year = 2;
    s1.program = "GTR";

    s2.ID = 345;
    s2.name = "Seyha";
    s2.year = 2;
    s2.program = "GTR";

    s3.ID = 567;
    s3.name = "Virak";
    s3.year = 2;
    s3.program = "GTR";

    s4.ID = 789;
    s4.name = "Neath";
    s4.year = 2;
    s4.program = "GTR";

    s5.ID = 168;
    s5.name = "Heng";
    s5.year = 2;
    s5.program = "GTR";
    
    add(s1, y);
    add(s2, y);
    add(s3, y);
    add(s4, y);
    add(s5, y);
    display(y);
}



