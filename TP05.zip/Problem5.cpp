#include<iostream>
using namespace std;

struct node{
    int data;
    node *link;
};

node *head = NULL;

void add_num(int num){
    node *n = new node();
    n -> data = num;
    n -> link = head;
    head = n;
}

void display(){
    int sum = 0;
    node *tmp = head;
  
    while(tmp != NULL){
        cout << tmp -> data << " ";
        sum = sum + tmp -> data;
        tmp = tmp -> link;
    }
    cout << "The sum is: " << sum << endl;
}

int main(){

    int count = 2;
    int num;

    while(count != 0 ){
        cout << "Enter number:";
        cin >> num ;
        if(num!=0){
            add_num(num);
        }
        if(num == 0){
            count = count-1;
            if(count == 1){
                cout << "You have entered the number 0 once. only 1 more left. we will quit the program." << endl;
            }else if(count == 0){
                cout << "You have entered the number 0 twice so far. The program is going to stop now." << endl;
            }
        }

    }
    display();
}
