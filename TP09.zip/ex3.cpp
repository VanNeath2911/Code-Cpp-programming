#include<iostream>

using namespace std;

struct Element {
    int data ;
    Element *next;
};

struct Stack {
    int n;
    Element *top;
};

Stack *EmptyStack (){
    Stack *s = new Stack ();
    s->n = 0;
    s->top = NULL;

    return s;
};

void push (Stack *s , int newdata){
    Element *e = new Element ();
    e->data = newdata ;
    e->next = s->top ;
    s->top = e ;
    s->n++;

}

void display(Stack *s){
    Element *tmp = s->top ;

    while (tmp!= NULL){
        cout<<tmp->data ;
        tmp = tmp->next;
    }
}

void pop(Stack *s){
    if (s->n==0){
        cout<<"Stack is empty!\n";
    }else{  
    Element *e = s->top;
    s->top = s->top->next;
    delete e;
    s->n--;
    }
}
int main (){
    Stack *s = EmptyStack ();

    int Decimal;
    int quotient,remainder;
    
    cout<<"Enter Decimal to change to Binary: ";
    cin>>Decimal;
    quotient = Decimal;
    while (quotient!=0){
        remainder = quotient%2;
        push(s,remainder); 
        quotient/=2;
    }    
    cout<<"The binary equivalent of "<<Decimal<<" is ";
    display(s);
    
}