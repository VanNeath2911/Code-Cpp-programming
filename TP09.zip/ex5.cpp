#include <iostream>

using namespace std;
struct element{
    char charator;
    element *next;
};
struct stack{
    int n;
    element *top;
};
stack* emptystack(){
    stack *s = new stack();
    s->n = 0;
    s->top = NULL;

    return s;
}
void push(stack *s,char data){
    element *e = new element();
    e->charator = data;
    e->next = s->top;
    s->top = e;
    s->n++;
}
char pop(stack *s){
    if (s->n==0){
        cout<<"Stack is empty..."<<endl;
        return '\0';
    }else{
        element *e = s->top;
        char data = e->charator;
        s->top = s->top->next;
        delete e;
        s->n--;
        return data;
    }
}
void display(stack *s){
    element *e= s->top;
    while (e!=NULL){
        cout<<e->charator<<"  ";
        e = e->next;
    }  
}

int main() {

    stack *s = emptystack();
    string input;
    cout<<"Enter string containing parentheses, braces and/or curly braces: ";getline(cin,input);
    int check=1;
    for (int i = 0; i < input.length(); i++){
        char right = input[i];
        if (right == '(' || right == '{' || right == '['){     
            push(s,right);
        }else if (right == ')' || right == '}' || right == ']'){ 
            if (s->n==0){
                cout<<"Stack is empty...\n";
                check=0;
                break;
            }else{
                char left = pop(s); 
                if (!((left == '(' && right == ')') || (left == '{' && right == '}') || (left == '[' && right == ']'))){
                        check=0;
                    break;
                }
            }
        } 
    }
    if (s->n != 0){
        check=0;
    }
    
    if (check){
        cout<<"Balanced!\n";
    }else{
        cout<<"Not Balanced!\n";
    }
    
    display(s);
    

    return 0;
}
