#include<iostream>
using namespace std;
struct Element{
    int number;
    Element *next;
};
struct stack{
    Element *top;
    int Size;
};
stack *EmptyStack(){
    stack *ls; 
    ls = new stack;
    ls -> Size = 0;
    ls -> top = NULL;
    return ls;
}
void push(stack *ls, int number){
    Element *e;
    e = new Element;
    e -> number = number;
    e -> next = ls -> top;
    ls -> top = e;
}
void display(stack *ls){
    Element *tmp;
    tmp = ls -> top;
    while(tmp != NULL){
        cout << tmp -> number << " ";
        tmp = tmp -> next;
    }
    cout << endl;
}
int main(){
    stack *ls;
    ls = EmptyStack();
    int n;
    cout << "Enter number in decimal: "; cin >> n;
    while(n > 0){
        int x;
        x = n % 2;
        push(ls, x);
        n/=2;
    }
    cout << "Decimal to binary: ";
    display(ls);
}