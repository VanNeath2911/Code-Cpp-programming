#include<iostream>
using namespace std;
struct element{
    string text;
    element *next;
};
struct stack{
    int size;
    element *top;
};
stack *EmptyStack(){
    stack *s;
    s = new stack;
    s -> size = 0;
    s -> top = NULL;
    return s;
}


