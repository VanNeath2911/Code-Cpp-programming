#include<iostream>
using namespace std;
struct element{
    char charator;
    element *next;
};
struct stack{
    int n;
    element *top;
};
stack* emptystack(){
    stack *s = new stack();
    s->n = 0;
    s->top = NULL;

    return s;
}
void push(stack *s,char data){
    element *e = new element();
    e->charator = data;
    e->next = s->top;
    s->top = e;
    s->n++;
}
void pop(stack *s){
    if (s->n==0){
        cout<<"Stack is empty..."<<endl;
    }else{
        element *e = s->top;
        s->top = s->top->next;
        delete e;
        s->n--;
    }
}
void display(stack *s){
    element *e= s->top;
    while (e!=NULL){
        cout<<e->charator<<"  ";
        e = e->next;
    }  
}
int main(){

    stack *s = emptystack();
    string operation = "E A S * Y * Q U E * * * S T * * * I O * N * * * ";
    string output;
    for (int i = 0; i < operation.length(); i++){
        char op = operation[i];
        if (op=='*'){
            if(s->n > 0){
                char out = s->top->charator;
                pop(s);
                
            }else{
                cout<<"Stack is empty\n";
            }
        }else{
            push(s,op);
        }    
    }
    //cout<<output;
    //or
   display(s);

    return 0;
}