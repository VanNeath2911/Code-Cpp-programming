#include<iostream>
using namespace std;
struct element{
    char letter;
    element *next;
};
struct stack{
    element *top;
    int size;
};
stack *createEmptyStack(){
    stack *s;
    s = new stack;
    s -> size = 0;
    s -> top = NULL;
    return s;
}
void push(stack *s, char letter){ //for add element to stack.
    element *e = new element();
    e -> letter = letter;

    e -> next = s -> top;
    s -> top = e;
}
char peek(stack *s){ //for return element that input last element.
    return s -> top -> letter;
}
void display(stack *s){
    element *tmp;
    tmp = s -> top;
    while(tmp != NULL){
        cout << tmp -> letter << " ";
        tmp = tmp -> next;
    }
    cout << endl;
}
int main(){
    stack *s;
    s =createEmptyStack();
    string input;
    cout << "Enter a text: ";
    cin >> input;

    for(int i = 0; i < input.length(); i++){
        push(s, input[i]);
    }
    display(s);
    peek(s);
}

