#include <iostream>

using namespace std;

struct Element {
    char letter ;
    Element *next;
};

struct Stack {
    int size;
    Element *top;
};

Stack *EmptyStack (){
    Stack *s = new Stack ();
    s->size = 0;
    s->top = NULL;

    return s;
};

void push (Stack *s , char letter){
    Element *e = new Element ();
    e->letter = letter ;

    e->next = s->top ;
    s->top = e ;

    s->size++;

}

void display(Stack *s){
    Element *tmp = s->top ;

    while (tmp!= NULL){
        cout<<tmp->letter<<"";
        tmp = tmp->next;
    }
}

char peek(Stack *s){

    return s->top->letter;
}

int main (){
    Stack *s = EmptyStack ();

    string input ;

    cout<<"Enter a text : ";
    cin>>input ;

    for(int i=0; i < input.length (); i++ ){

        push (s, input[i]);
    }
    display(s);
    cout<<"Top is : "<<endl;
    cout<<peek(s);
}