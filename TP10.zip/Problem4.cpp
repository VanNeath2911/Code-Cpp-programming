#include <iostream>
using namespace std;
// Define the structure for a node
struct Node {
    int data;
    Node* next;
};
// Function to create a new node
Node* createNode(int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = nullptr;
    return newNode;
}
// Function to add a node to the end of the linked list
void addNode(Node*& head, int data) {
    Node* newNode = createNode(data);
    if (head == nullptr) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}
// Function to print the linked list
void printList(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
// Function to sort the linked list using bubble sort
void bubbleSort(Node* head) {
    if (head == nullptr) return;
    bool swapped;
    Node* ptr1;
    Node* lptr = nullptr;
    do {
        swapped = false;
        ptr1 = head;

        while (ptr1->next != lptr) {
            if (ptr1->data > ptr1->next->data) {
                swap(ptr1->data, ptr1->next->data);
                swapped = true;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    } while (swapped);
}
// Function to free the linked list memory
void freeList(Node*& head) {
    Node* temp;
    while (head != nullptr) {
        temp = head;
        head = head->next;
        delete temp;
    }
}
int main() {
    Node* head = nullptr;
    int number;
    cout << "Enter 10 numbers:" << endl;
    for (int i = 0; i < 10; ++i) {
        cout << "Number " << i + 1 << ": ";
        cin >> number;
        addNode(head, number);
    }
    cout << "The numbers in the linked list are: ";
    printList(head);
    bubbleSort(head);
    cout << "The sorted numbers in the linked list are: ";
    printList(head);
    // Free the allocated memory
    freeList(head);
    return 0;
}