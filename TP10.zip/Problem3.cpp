#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

struct Student {
    int id;
    string name;
    string gender;
};

vector<Student> readCSV(const string& filename) {
    vector<Student> students;
    ifstream file(filename);
    string line, word;

    if (file.is_open()) {
        // Skip the header line
        getline(file, line);

        while (getline(file, line)) {
            stringstream s(line);
            Student student;

            // Read ID
            getline(s, word, ',');
            student.id = stoi(word);

            // Read name
            getline(s, student.name, ',');

            // Read gender
            getline(s, student.gender, ',');

            students.push_back(student);
        }
        file.close();
    } else {
        cerr << "Unable to open file: " << filename << endl;
    }

    return students;
}

void printStudents(const vector<Student>& students) {
    for (const auto& student : students) {
        cout << "ID: " << student.id << ", Name: " << student.name << ", Gender: " << student.gender << endl;
    }
}

bool compareByID(const Student& a, const Student& b) {
    return a.id < b.id;
}

bool compareByName(const Student& a, const Student& b) {
    return a.name < b.name;
}

bool compareByGender(const Student& a, const Student& b) {
    return a.gender < b.gender;
}

void menu() {
    cout << "Sort by: " << endl;
    cout << "a. ID" << endl;
    cout << "b. Name" << endl;
    cout << "c. Gender" << endl;
    cout << "Enter choice: ";
}

int main() {
    string filename = "students.csv";
    vector<Student> students = readCSV(filename);

    menu();
    char choice;
    cin >> choice;

    switch (choice) {
        case 'a':
            sort(students.begin(), students.end(), compareByID);
            break;
        case 'b':
            sort(students.begin(), students.end(), compareByName);
            break;
        case 'c':
            sort(students.begin(), students.end(), compareByGender);
            break;
        default:
            cout << "Invalid choice" << endl;
            return 1;
    }

    printStudents(students);

    return 0;
}