#include <iostream>
#include <fstream>
using namespace std;

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}
//a. Sort using selection sort algorithm
void selectionSort(int arr[], int n) {
    int i, j, min;
    for (i = 0; i < n-1; i++) {
        min = i;
        for (j = i+1; j < n; j++) {
            if (arr[j] < arr[min]) {
                min = j;
            }
        }
        swap(&arr[min], &arr[i]);
    }
}
void displaySort(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
int main() {
    fstream file;
    file.open("selection.txt", ios::in);
    int num[9];
    int i = 0;
    while (i < 9 && file >> num[i]) {
        i++;
    }
    file.close();
    
    file.open("selection.txt", ios::out);
    for (int i = 0; i < 9; i++) {
        file << num[i] << " " << endl;
    }
    selectionSort(num, 9);
    cout<<"\nsorted array: ";
    for (int i = 0; i < 9; i++) {
        file << num[i] << " " << endl;
    }
    file.close();
    
    displaySort(num, 9);
    return 0;
}