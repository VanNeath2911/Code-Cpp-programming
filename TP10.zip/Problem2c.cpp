#include <iostream>
#include <fstream>
using namespace std;

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}
//c. Sort using insertion sort algorithm 
void insertionSort(int arr[], int n){
    int i;
    for (int i = 1; i < n; i++){
        int key =arr[i];
        int j = i-1;
        while (j >= 0 && arr[i]>key){
            arr[j+1] = arr[i];
            j = j-1;
        }
        arr[j+1]=key;
    }
}

void displaySort(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
int main() {
    fstream file;
    file.open("insertion.txt", ios::in);
    int num[9];
    int i = 0;
    while (i < 9 && file >> num[i]) {
        i++;
    }
    file.close();
    
    file.open("insertion.txt", ios::out);
    for (int i = 0; i < 9; i++) {
        file << num[i] << " " << endl;
    }
    insertionSort(num, 9);
    insertionSort(num,9);

    cout<<"\nsorted array: ";
    for (int i = 0; i < 9; i++) {
        file << num[i] << " " << endl;
    }
    file.close();
    
    displaySort(num, 9);
    return 0;
}