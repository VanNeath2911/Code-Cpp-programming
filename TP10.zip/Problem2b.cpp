#include <iostream>
#include <fstream>
using namespace std;

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

void displaySort(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void bubbleSort(int arr[],int n){
    int i,j;
    for (int i=0; i<n-1; i++){
        for (int j=0; j<n-i-1;j++){
            if (arr[j]> arr[j+1]){
                swap(arr[j], arr[j+1]);
            }
        }
    }
}
int main() {
    fstream file;
    file.open("bubble.txt", ios::in);
    int num[9];
    int i = 0;
    while (i < 9 && file >> num[i]) {
        i++;
    }
    file.close();
    
    file.open("bubble.txt", ios::out);
    for (int i = 0; i < 9; i++) {
        file << num[i] << " " << endl;
    }
    bubbleSort(num, 9);
    bubbleSort(num,9);

    cout<<"\nsorted array: ";
    for (int i = 0; i < 9; i++) {
        file << num[i] << " " << endl;
    }
    file.close();
    
    displaySort(num, 9);
    return 0;
}