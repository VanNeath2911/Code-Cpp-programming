#include <iostream>
#include <algorithm> 
using namespace std;
int main() {
    int size = 5; 
    int numbers[size]; 

    // Asking user to input 5 numbers
    for (int i = 0; i < size; ++i) {
        cout << "Enter numbers #" << i+1 << ":";
        cin >> numbers[i];
    }
    // Sorting the array in ascending order
    sort(numbers, numbers + size);
    // Displaying the sorted array in ascending order
    cout << "Numbers sorted from smallest to largest: ";
    for (int i = 0; i < size; ++i) {
        cout << numbers[i] << " ";
    }
    cout << endl;
    // Sorting the array in descending order
    sort(numbers, numbers + size, greater<int>());

    // Displaying the sorted array in descending order
    cout << "Numbers sorted from largest to smallest: ";
    for (int i = 0; i < size; ++i) {
        cout << numbers[i] << " ";
    }
    cout << endl;
    return 0;
}
