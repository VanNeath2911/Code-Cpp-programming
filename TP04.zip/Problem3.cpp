#include <iostream>
using namespace std;
void exchange(float *a, float *b){
    int tmp;
    tmp = *a;
    *a = *b;
    *b = tmp;
    cout << "After" << endl;
    cout << "a = " << a <<endl;
    cout << "b = " << b <<endl;
}
int main(){
    float a = 5, b = 10;
    cout << "Before" << endl;
    cout << "a = " << a <<endl;
    cout << "b = " << b <<endl;

    exchange(&a,&b);
}