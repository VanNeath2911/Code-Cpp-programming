#include<iostream>
using namespace std;

void sum1(double *sum, int n){
    *sum = 0;
    for(int i=1; i<=n; i++){
        *sum = *sum+1.0/((i*10)+2);
    }
}
int main(){
    double result ;
    sum1(&result, 5);
    cout << result <<endl;
}