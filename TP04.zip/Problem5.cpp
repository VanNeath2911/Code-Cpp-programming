#include<iostream>
using namespace std;

void findMaxMin(int number[], int *max, int *min){
    *max = number[0];
    *min = number[0];
    for(int i=1; i<7; i++){
        if(number[i] > *max){
            *max = number[i]; 
        }
        if(number[i] < *min){
            *min = number[i];
        }
    }
    cout << "Max number is "<< *max << endl;
    cout << "Min number is "<< *min << endl;
}
int main(){
    int number[7];
    int max, min;
    for(int j=0; j<=6; j++){
        cout << "Enter number " << j+1 << ": ";
        cin >> number[j];
    }
    findMaxMin(number, &max, &min);
    // cout << "Max number is "<< max << endl;
    // cout << "Min number is "<< min << endl;
    return 0;
}