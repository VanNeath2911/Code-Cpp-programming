#include<iostream>
using namespace std;

int main(){
    int n;
    int *p;

    cout << "Enter a number: ";
    cin >> n;

    p = &n;
    *p = *p + 7;

    cout << "The value = "<< *p << endl;
}
