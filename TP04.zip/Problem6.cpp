#include<iostream>
using namespace std;
int main(){
    float number[7];
    float *p[7];
    float sum=0;
    float mult=1;
    for(int i=1; i<=7; i++){
        cout<<i<<". Enter number: ";cin>>number[i];
    }
    for(int i=1; i<=7; i++){
        p[i]=&number[i];
        cout<<*p[i]<<" ";
    }
    cout<<"\t\n";
    for(int i=1; i<=7; i++){
        sum=sum+*p[i];
    mult=(mult)*(*p[i]);
    }
    cout<<sum<<endl;
    cout<<"\t\n";
    cout<<mult<<endl;
}
