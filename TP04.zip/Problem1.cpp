#include<iostream>
using namespace std;

int main(){
    int n1 = 7;
    int n2 = 3;
    int n3 = 15;

    int *p1 = &n1;
    int *p2 = &n2;
    int *p3 = &n3;

    cout << "Adress n1: " << &n1 << endl;
    cout << "Adress n2: " << &n2 << endl;
    cout << "Adress n3: " << &n3 << endl;

    *p3 = *p2 + *p1;

    cout << "Value of p3: " << *p3 << endl;

    return 0;
}
