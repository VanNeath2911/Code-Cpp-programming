#include<iostream>
#include<math.h>
using namespace std;
void SolveEquation(int a , int b , int c , float *x1 , float *x2 , float *delta){
    *delta = pow(b,2) - 4 * a * c;

    if(*delta > 0){
        *x1 = -b + sqrt(*delta) / (2*a);
        *x2 = -b - sqrt(*delta) / (2*a);
        cout << "The equation has two roots is: " << endl;
        cout << "x1: " << *x1 << endl;
        cout << "x2: " << *x2 << endl;
    }
    if(*delta == 0){
        *x1 = *x2 = -b /(float)(2*a);
        cout << "The equation has double roots is: " << *x1 << endl;
    }
    if(*delta < 0){
        cout << "The equation has no roots." << endl;
    }

}
int main(){
    int a , b , c; 
    float x1 , x2 , delta;

    cout << "Enter a: "; cin >> a;
    cout << "Ente b: "; cin >> b;
    cout << "Enter c: "; cin >> c;

    if(a == 0){
        cout << "a must be bigger than 0." << endl;
        cout << " Try again! " << endl;
    }else{
        SolveEquation(a , b , c , &x1 , &x2 , &delta);
    }
    return 0;
}
