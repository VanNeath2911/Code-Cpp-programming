#include<iostream>
using namespace std;
struct Node {
    char data;
    Node* next;
};
void insertAtBeginning(Node** head, char data) {
    Node* newNode = new Node;
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}
void display(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout<< temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
int main() {
    Node* Alphabets = NULL;
    Node* AlphabetsSmall= NULL;
    for(char ch='a';ch<='z';ch++){
    	insertAtBeginning(&AlphabetsSmall,ch);
	}
    for (char ch = 'A'; ch <= 'Z'; ch++) {
        insertAtBeginning(&Alphabets, ch);
    }
    cout<<"Upper Alphabets: ";
    display(Alphabets);
    cout<<"Small Letters  : ";
    display(AlphabetsSmall);
    return 0;
}



