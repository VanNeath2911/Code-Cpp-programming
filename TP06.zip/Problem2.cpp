#include<iostream>
#include<string>
using namespace std;
struct Node{
	string name;
	Node *next;
	
	Node(string name){
		this->name = name;
		this->next = NULL;
	}
};
Node *createList(){
	return NULL;
}
void addPerson(Node* &head,string name){
	Node *newNode = new Node(name);
	newNode->next = head;
	head = newNode;
}
void displayList(Node *head){
	Node *tmp = head;
	while(tmp != NULL){
		cout<<tmp->name<<"\n";
		tmp = tmp->next;
	}
}
int main(){
	Node *head = createList();
	
	addPerson(head,"Seyha");
	addPerson(head,"Sutha");
	addPerson(head,"Virak");
	addPerson(head,"Vanneath");
	addPerson(head,"Heng");
	addPerson(head,"Channa");
	addPerson(head,"Phanna");
	addPerson(head,"Sreyneang");
	addPerson(head,"Netra");
	addPerson(head,"Tola");
	
	cout<<"Names: " << endl;
 	displayList(head);

	
	return 0;	
}


  