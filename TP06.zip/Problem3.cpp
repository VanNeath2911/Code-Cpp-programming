#include<iostream>
#include<string.h>
#include<conio.h>
using namespace std;
struct Product{
    string name, ExpDate, Type;
    float price;
    int quantity, ID;
    Product *link;
};
struct ListProduct{
    int n;
    Product *head;
    Product *tail;
};
ListProduct *createEmptyList(){
    ListProduct *mylist;
    mylist = new ListProduct;
    mylist->n = 0 ;
    mylist->head = NULL;
    mylist->tail = NULL;

    return mylist;
}
void addProductBegin(ListProduct *mylist, string name, int ID,  float price, int quantity, string type, string ExpDate){
    Product *product;
    product = new Product;
    product -> name     = name;
    product -> ExpDate  = ExpDate;
    product -> price    = price;
    product -> quantity = quantity;
    product -> ID       = ID;
    product -> Type     = type;

    product->link = mylist->head;
    mylist->head  = product;
    
    if(mylist->n==0){
        mylist->tail = mylist->head = product;
    }
    mylist->n = mylist->n+1;
}
void addProductEnd(ListProduct *mylist, string name, int ID,  float price, int quantity, string type, string ExpDate){
    Product *product;
    product = new Product;
    product-> name     = name;
    product-> ExpDate  = ExpDate;
    product-> price    = price;
    product-> quantity = quantity;
    product-> ID       = ID;
    product-> Type     = type;

    product->link = NULL;
    if(mylist->n==0){
        mylist->tail = mylist->head = product;
    }
  else{
        mylist->tail->link = product;
        mylist->tail = product;
    }
    mylist->n = mylist->n+1;
}
void display(ListProduct *mylist){
    Product *tmp;
    tmp = mylist->head;
    if(mylist->n==0){
        cout<<"The list is empty"<<endl;
    }else{
        while(tmp!=NULL){
            cout<<"Name    : "<<tmp->name<<endl;
            cout<<"ID      : "<<tmp->ID<<endl;
            cout<<"Type    : "<<tmp->Type<<endl;
            cout<<"Price   :$"<<tmp->price<<endl;
            cout<<"Quantity: "<<tmp->quantity<<endl;
            cout<<"Exp date: "<<tmp->ExpDate<<endl;
            tmp = tmp->link;
        }
    }
}
void Search(ListProduct *mylist, string name){
    Product *tmp;
    tmp = mylist->head;

    if(mylist->n==0){
        cout<<"The list is empty"<<endl;
    }
  else{
        while(tmp!=NULL){
            if(name==tmp->name){
                cout<<"\nHere's the product's detail:"<<endl;
                cout<<"Name    : "<<tmp->name<<endl;
                cout<<"ID      : "<<tmp->ID<<endl;
                cout<<"Type    : "<<tmp->Type<<endl;
                cout<<"Price   :$"<<tmp->price<<endl;
                cout<<"Quantity: "<<tmp->quantity<<endl;
                cout<<"Exp date: "<<tmp->ExpDate<<endl;
                break;
            }
            tmp = tmp->link;
        }
    }
}
void searchProduct_Higher(ListProduct *mylist, float balance){
    Product *tmp;
    tmp = mylist->head;
    while(tmp!=NULL){
        if(tmp->price >= balance){
            cout<<"Name    : "<<tmp->name<<endl;
            cout<<"ID      : "<<tmp->ID<<endl;
            cout<<"Type    : "<<tmp->Type<<endl;
            cout<<"Price   :$"<<tmp->price<<endl;
            cout<<"Quantity: "<<tmp->quantity<<endl;
            cout<<"Exp date: "<<tmp->ExpDate<<endl;
        }
        tmp = tmp->link;
    }
}
void searchProduct_Lower(ListProduct *mylist, float balance){
    Product *tmp;
    tmp = mylist->head;
    while(tmp!=NULL){
        if(tmp->price <= balance){
            cout<<"\nName  : "<<tmp->name<<endl;
            cout<<"ID      : "<<tmp->ID<<endl;
            cout<<"Type    : "<<tmp->Type<<endl;
            cout<<"Price   : $"<<tmp->price<<endl;
            cout<<"Quantity: "<<tmp->quantity<<endl;
            cout<<"Exp date: "<<tmp->ExpDate<<endl;
        }
        tmp = tmp->link;
    }
}
int main(){
    string name, ExpDate, Type, search;
    float price, balance;
    int quantity, ID, opt, choice;
    
    ListProduct *mylist;
    mylist = createEmptyList();
    cout<<"Menu\n";
    cout<<" 1.Add new product "<<endl;
    cout<<" 2.Search product by price "<<endl;
    cout<<" 3.Display all product "<<endl;
    cout<<" 4.Search product by name "<<endl;
    cout<<" 5.Exit program"<<endl;
    cout<<"=========================\n";
    
    do{
        cout<<"Choose one option: ";cin>>opt;
        switch(opt){
            case(1):
                cout<<"Enter the product's name: "; cin>>name;
                cout<<"Enter the product's ID: "; cin>>ID;
                cout<<"Enter the product's price:$"; cin>>price;
                cout<<"Enter the product's type: "; cin>>Type;
                cout<<"Enter the product's quantity: "; cin>>quantity;
                cout<<"Enter the product's expiry date: "; cin>>ExpDate;
                    if(price<50){
                        addProductBegin(mylist, name, ID, price, quantity, Type, ExpDate);
                    }else if(price>=50){
                        addProductEnd(mylist, name, ID, price, quantity, Type, ExpDate);
                    }
                break;
            case(2):
            if(mylist->n==0){
                cout<<"The list is currently empty."<<endl;
            }else{
                  cout<<"Please enter a price you want to search for: "; cin>>balance;
                  cout<<"Please pick an option: "<<endl;
                  cout<<"1.Search for product's that's equal to and higher"<<endl;
                  cout<<"2.Search for product's that's equal to and lower"<<endl;
                  cout<<"Choose one: ";cin>>choice;
                  switch(choice){
                      case(1):
                        searchProduct_Higher(mylist, balance);
                        break;
                      case(2):
                        searchProduct_Lower(mylist, balance);
                        break;
                      default:
                        cout<<"Please choose a valid choice between 1 and 2.";
                        break;
                    }
                }
            break;

            case(3):
            cout<<"\t\tHere are the available products:\n";
            display(mylist);
            break;

            case(4):
            cout<<"\t\tPlease enter the product's name: "; cin>>search;
            Search(mylist, search);
            break;
      
            case(5):
            cout<<"Exiting program..."<<endl;
            break;

            default:
            cout<<"Please choose a valid option of 1 to 4.";
            break;  
        }
    } while(opt != 5);
}
