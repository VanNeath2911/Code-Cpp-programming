#include <iostream>
using namespace std;

struct Products {
    float price;
    string name;
    string quality;
    int id;
    int date;
    int expired;
    string type;
    Products* next;
};

struct Listproduct {
    int n;
    Products* head;
    Products* tail;
};

Listproduct* Emptylist(){

    Listproduct* pro_duct = new Listproduct;
    pro_duct->n = 0;
    pro_duct->head = NULL;
    pro_duct->tail = NULL;
    return pro_duct;

}

void addproduct_tobegin(Listproduct* ls, int id, string name, string type , float price, string quality, int date, int expired){

    Products* tmp_begin = new Products;
    tmp_begin->id = id;
    tmp_begin->name = name;
    tmp_begin -> type = type;
    tmp_begin->price = price;
    tmp_begin->quality = quality;
    tmp_begin->date = date;
    tmp_begin->expired = expired;

    tmp_begin->next = ls->head;
    ls->head = tmp_begin;
    if (ls->tail == NULL) {
        ls->tail = tmp_begin;
    }
    ls->n++;

}

void addproduct_toend(Listproduct* ls, int id, string name, string type , float price, string quality, int date, int expired){

    Products* tmp_end = new Products;
    tmp_end->id = id;
    tmp_end->name = name;
    tmp_end->type = type;
    tmp_end->price = price;
    tmp_end->quality = quality;
    tmp_end->date = date;
    tmp_end->expired = expired;

    tmp_end->next = NULL;
    if (ls->head == NULL) {
        ls->head = tmp_end;
        ls->tail = tmp_end;
    } else {
        ls->tail->next = tmp_end;
        ls->tail = tmp_end;
    }
    ls->n++;

}

void display_product(Listproduct* ls){

    Products* tmp_display = ls->head;
    cout << "Here your products: " << endl;

    while (tmp_display != NULL) {
        cout << "\nID: " << tmp_display->id << endl;
        cout << "Name: " << tmp_display->name << endl;
        cout << "TYpe: " << tmp_display->type << endl;
        cout << "Price: $" << tmp_display->price << endl;
        cout << "Quality: " << tmp_display->quality << endl;
        cout << "Date: " << tmp_display->date << endl;
        cout << "Expired: " << tmp_display->expired << endl;
        tmp_display = tmp_display->next;
    }

}

void searchby_name(Listproduct* ls){

    string Product_name;
    cout << "Enter name of product: ";
    cin >> Product_name;
    Products* tmp_name = ls->head;
    bool found = false;

    while (tmp_name != NULL) {
        if (Product_name == tmp_name->name) {
            cout << "\nID: " << tmp_name->id << endl;
            cout << "Name: " << tmp_name->name << endl;
            cout << "Type: " << tmp_name->type << endl;
            cout << "Price: $" << tmp_name->price << endl;
            cout << "Quality: " << tmp_name->quality << endl;
            cout << "Date: " << tmp_name->date << endl;
            cout << "Expired: " << tmp_name->expired << endl;
            found = true;
        }
        tmp_name = tmp_name->next;
    }

    if(!found){
        cout << "Your product hasn't been found." << endl;
    }

}

void search_lower(Listproduct* ls, float money){

    Products* tmp_lower = ls->head;
    bool found = false;
    while (tmp_lower != NULL) {
        if (tmp_lower->price <= money) {
            cout << "\nID: " << tmp_lower->id << endl;
            cout << "Name: " << tmp_lower->name << endl;
            cout << "Type: " << tmp_lower->type << endl;
            cout << "Price: $" << tmp_lower->price << endl;
            cout << "Quality: " << tmp_lower->quality << endl;
            cout << "Date: " << tmp_lower->date << endl;
            cout << "Expired: " << tmp_lower->expired << endl;
            found = true;
        }
        tmp_lower = tmp_lower->next;
    }
    if(!found){
        cout << "No products found within the price range." << endl;
    }
    
}

void search_high(Listproduct* ls, float money){
    Products* tmp_high = ls->head;
    bool found = false;
    while (tmp_high != NULL) {
        if (tmp_high->price >= money) {
            cout << "\nID: " << tmp_high->id << endl;
            cout << "Name: " << tmp_high->name << endl;
            cout << "Type: " << tmp_high->type << endl;
            cout << "Price: $" << tmp_high->price << endl;
            cout << "Quality: " << tmp_high->quality << endl;
            cout << "Date: " << tmp_high->date << endl;
            cout << "Expired: " << tmp_high->expired << endl;
            found = true;
        }
        tmp_high = tmp_high->next;
    }
    if(!found){
        cout << "No products found within the price range." << endl;
    }

}

void deletefrom_begin(Listproduct* ls){

    if (ls->n == 0) {
        cout << "Oops! Cannot delete. List is empty." << endl;
    } else if (ls->n == 1) {
        Products* delete_begin = ls->head;
        ls->head = NULL;
        ls->tail = NULL;
        ls->n = 0;
        delete delete_begin;
    } else {
        Products* delete_begin = ls->head;
        cout << "Products has been delete." << endl;
        ls->head = ls->head->next;
        delete delete_begin;
        ls->n--;
    }

}

int main() {

    float price, money;
    string name, quality , type;
    int id, date, expired, n;
    char choice;

    Listproduct* L1 = Emptylist();

        cout << "******************** MENU ********************" << endl;
        cout << "\tA. Add your product." << endl;
        cout << "\tB. Display your product." << endl;
        cout << "\tC. Search product by name." << endl;
        cout << "\tD. Search product by price." << endl;
        cout << "\tE. Delete product from beginning." << endl;
        cout << "\tF. Exit the program." << endl;

    while(1){
        cout << "\nEnter your choice: ";
        cin >> choice;
        cout << "\n";

        switch (choice) {
            case 'A':
                cout << "Enter ID of product: ";
                cin >> id;
                cout << "Enter Name of product: ";
                cin >> name;
                cout << "Enter Type of product: ";
                cin >> type;
                cout << "Enter Price of product: $";
                cin >> price;
                cout << "Enter Quality of product: ";
                cin >> quality;
                cout << "Enter Date of product: ";
                cin >> date;
                cout << "Enter Expired of product: ";
                cin >> expired;
                if (price >= 50) {
                    addproduct_toend(L1, id, name, type ,price, quality, date, expired);
                } else {
                    addproduct_tobegin(L1, id, name, type , price, quality, date, expired);
                }
                break;
            case 'B':
                display_product(L1);
                break;
            case 'C':
                searchby_name(L1);
                break;
            case 'D':
                cout << "Have 2 price options (Lower or High)." << endl;
                cout << "1. Enter low price." << endl;
                cout << "2. Enter high price." << endl;
                cout << "Enter options: ";
                cin >> n;
                cout << "Enter price: ";
                cin >> money;
                switch(n){
                    case 1:
                        search_lower(L1, money);
                        break;
                    case 2:
                        search_high(L1, money);
                        break;
                    default:
                        cout << "Invalid price option." << endl;
                        break;
                }
                break;
            case 'E':
                deletefrom_begin(L1);
                break;
            case 'F':
                cout << "Exit the program....." << endl;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
    return 0;
}