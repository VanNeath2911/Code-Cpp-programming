#include <iostream>
#include <ctime>
using namespace std;

struct ElementNum {
    int number;
    ElementNum *next;
    ElementNum *previous;
};

struct Listnum {
    int n;
    ElementNum *head;
    ElementNum *tail;
};

Listnum *Emptynum() {
    Listnum *tp = new Listnum;
    tp->n = 0;
    tp->head = NULL;
    tp->tail = NULL;
    return tp;
}

void AddtoBegin(Listnum *ls, int Newnumber) {
    ElementNum *tmp = new ElementNum;
    tmp->number = Newnumber;
    tmp->previous = NULL;
    tmp->next = ls->head;

    if (ls->n == 0) {
        ls->head = tmp;
        ls->tail = tmp;
    } else {
        ls->head->previous = tmp;
        ls->head = tmp;
    }
    ls->n++;
}
void AddtoEnd(Listnum *ls, int Newnumber) {
    ElementNum *tmp = new ElementNum;
    tmp->number = Newnumber;
    tmp->next = NULL;
    tmp->previous = ls->tail;

    if (ls->n == 0) {
        ls->head = tmp;
        ls->tail = tmp;
    } else {
        ls->tail->next = tmp;
        ls->tail = tmp;
    }
    ls->n++;
}
void AddPosition(Listnum *ls, int num, int pos) {
    if (pos < 1 || pos > ls->n + 1) {
        cout << "Invalid position." << endl;
        return;
    }
    if (pos == 1) {
        AddtoBegin(ls, num);
    } else if (pos == ls->n + 1) {
        AddtoEnd(ls, num);
    } else {
        ElementNum *e = new ElementNum;
        e->number = num;
        ElementNum *current = ls->head;
        for (int i = 1; i < pos; i++) {
            current = current->next;
        }
        e->previous = current->previous;
        e->next = current;
        current->previous->next = e;
        current->previous = e;
        ls->n++;
    }
}
void displayNumV1(Listnum *ls) {
    ElementNum *tmp = ls->head;
    while (tmp != NULL) {
        cout << tmp->number << " ";
        tmp = tmp->next;
    }
    cout << endl;
}
void displayNumV2(Listnum *ls) {
    ElementNum *tmp = ls->tail;
    while (tmp != NULL) {
        cout << tmp->number << " ";
        tmp = tmp->previous;
    }
    cout << endl;
}

void Summation(Listnum *ls) {
    if (ls->n == 0) {
        cout << "List is empty." << endl;
        return;
    }
    ElementNum *tmp = ls->head;
    float sum = 0;
    while (tmp != NULL) {
        sum += tmp->number;
        tmp = tmp->next;
    }
    float Average = sum / ls->n;
    cout << "Summation: " << sum << endl;
    cout << "Average: " << Average << endl;
}

void DeleteBegin(Listnum *ls) {
    if (ls->n == 0) {
        cout << "List is empty, nothing to delete." << endl;
        return;
    }
    cout << "Program has delete it." << endl;
    ElementNum *temp = ls->head;
    ls->head = ls->head->next;
    if (ls->head != NULL) {
        ls->head->previous = NULL;
    } else {
        ls->tail = NULL;
    }
    delete temp;
    ls->n--;
}
void DeleteEnd(Listnum *ls) {
    if (ls->n == 0) {
        cout << "List is empty, nothing to delete." << endl;
        return;
    }
    cout << "Program has delete it." << endl;
    ElementNum *temp = ls->tail;
    ls->tail = ls->tail->previous;
    if (ls->tail != NULL) {
        ls->tail->next = NULL;
    } else {
        ls->head = NULL;
    }
    delete temp;
    ls->n--;
}
void DeletePosition(Listnum *ls, int pos) {
    if (pos < 1 || pos > ls->n) {
        cout << "Invalid position." << endl;
        return;
    }
    if (pos == 1) {
        DeleteBegin(ls);
        return;
    }
    if (pos == ls->n) {
        DeleteEnd(ls);
        return;
    }
    cout << "Program has delete it." << endl;
    ElementNum *current = ls->head;
    for (int i = 1; i < pos; i++) {
        current = current->next;
    }
    current->previous->next = current->next;
    current->next->previous = current->previous;
    delete current;
    ls->n--;
}

void FindMinMax(Listnum *ls) {
    if (ls->n == 0) {
        cout << "List is empty." << endl;
        return;
    }
    ElementNum *tmp = ls->head;
    int min = tmp->number;
    int max = tmp->number;
    while (tmp != NULL) {
        if (min > tmp->number) {
            min = tmp->number;
        }
        if (max < tmp->number) {
            max = tmp->number;
        }
        tmp = tmp->next;
    }
    cout << "Min: " << min << endl;
    cout << "Max: " << max << endl;
}

int main() {
    char choice;
    Listnum *L1 = Emptynum();
    int num, pos;
    cout << "******MENU******" << endl;
    cout << "A. Add to Begin." << endl;
    cout << "B. Add to End." << endl;
    cout << "C. Add Position." << endl;
    cout << "D. Display List." << endl;
    cout << "E. Summation and Average." << endl;
    cout << "F. Delete from Begin." << endl;
    cout << "G. Delete from End." << endl;
    cout << "H. Delete from Position." << endl;
    cout << "I. Display Min and Max." << endl;
    cout << "J. Exit the program..." << endl;
    while (22) {
        cout << endl;
        cout << "Enter choice: ";
        cin >> choice;
        cout << endl;
        switch (choice) {
            case 'A':
                cout << "Enter number to add to the beginning: ";
                cin >> num;
                AddtoBegin(L1, num);
                break;
            case 'B':
                cout << "Enter number to add to the end: ";
                cin >> num;
                AddtoEnd(L1, num);
                break;
            case 'C':
                cout << "Enter number to add: ";
                cin >> num;
                cout << "Enter position to add: ";
                cin >> pos;
                AddPosition(L1, num, pos);
                break;
            case 'D':
                cout << "List: ";
                displayNumV1(L1);
                break;
            case 'E':
                Summation(L1);
                break;
            case 'F':
                DeleteBegin(L1);
                break;
            case 'G':
                DeleteEnd(L1);
                break;
            case 'H':
                cout << "Enter position to delete: ";
                cin >> pos;
                DeletePosition(L1, pos);
                break;
            case 'I':
                FindMinMax(L1);
                break;
            case 'J':
                cout << "Exit the program..." << endl;
                return 0;
            default:
                cout << "Please input a letter from A-J." << endl;
        }
    }

    return 0;
}