#include<iostream>
using namespace std;
int main(){
    string name;
    char gender;
    float salary;
    
    cout<< "Enter your name:";
    cin>>name;
    cout<< "Enter your gender:";
    cin>>gender;
    cout<< "Enter your salary:";
    cin>>salary;

    if(gender == 'M'){
        if(salary >= 1000){
            cout<< "Hello Mr."<<name<<". You pay tax 9.5%." << endl;
        }else if(salary >= 500){
            cout<< "Hello Mr."<<name<<". You pay tax 7%." << endl;
        }else if(salary >= 300){
            cout<< "Hello Mr."<<name<<". You pay tax 5%." << endl;
        }else{
            cout<< "Hello Mr."<<name<<". No need to pay tex." << endl;
        }
    }else if(gender == 'F'){
        if(salary >= 1000){
            cout<< "Hello Mrs."<<name<<". You pay tax 8%." << endl;
        }else if(salary >=500){
           cout<< "Hello Mrs."<<name<<". You pay tax 6.5%." << endl;
        }else if(salary >= 300){
             cout<< "Hello Mrs."<<name<<". You pay tax 3.5%." << endl;
        }else{
             cout<< "Hello Mrs."<<name<<". No need pay tax." << endl;
        }
    }
    return 0;
}