#include <iostream>
#include <cstdlib> 
#include <ctime>   

using namespace std;

int getComputerChoice() {
    return rand() % 3;
}

string convertChoiceToString(int choice) {
    switch (choice) {
        case 0:
            return "Rock";
        case 1:
            return "Paper";
        case 2:
            return "Scissors";
        default:
            return "Invalid";
    }
}


string determineWinner(int userChoice, int computerChoice) {
    if (userChoice == computerChoice) {
        return "It's a tie!";
    } else if ((userChoice == 0 && computerChoice == 2) ||
               (userChoice == 1 && computerChoice == 0) ||
               (userChoice == 2 && computerChoice == 1)) {
        return "You win!";
    } else {
        return "Computer wins!";
    }
}

int main() {
    srand(time(0)); 

    cout << "Let's play Rock-Paper-Scissors!" << endl;
    cout << "Enter your choice (0 for Rock, 1 for Paper, 2 for Scissors): ";
    int userChoice;
    cin >> userChoice;

    if (userChoice < 0 || userChoice > 2) {
        cout << "Invalid choice. Please enter 0, 1, or 2." << endl;
        return 1;
    }

    int computerChoice = getComputerChoice();

    cout << "You chose: " << convertChoiceToString(userChoice) << endl;
    cout << "Computer chose: " << convertChoiceToString(computerChoice) << endl;

    cout << determineWinner(userChoice, computerChoice) << endl;

    return 0;
}