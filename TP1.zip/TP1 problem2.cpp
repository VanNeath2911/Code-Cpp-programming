#include<iostream>
using namespace std;
int main(){
    char charater;
    while(1){
        cout << "Enter a charater from a to z: ";
        cin >> charater;

        if(charater == 'a' || charater == 'i' || charater == 'e' || charater == 'o' || charater == 'u'){
            cout << "Charater "<<charater<< " is a vowel." << endl;
        }else{
            cout << "Charater "<<charater<< " is a consonant." << endl;
        }
    }
}