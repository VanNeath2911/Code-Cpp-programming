#include <iostream>
#include <string>
using namespace std;

struct Author {
    string name;
};

struct Book {
    int bookID;
    string ISBN;
    string title;
    int publishedYear;
    Author authors[3]; 
    double price;
};

Book books[5]; 
int bookCount = 0; 

void displayBookInfoByISBN(string ISBN) {
    for (int i = 0; i < bookCount; i++) {
        if (books[i].ISBN == ISBN) {
            cout << "Book ID: " << books[i].bookID << endl;
            cout << "ISBN: " << books[i].ISBN << endl;
            cout << "Title: " << books[i].title << endl;
            cout << "Published Year: " << books[i].publishedYear << endl;
            cout << "Authors: ";
            for (int j = 0; j < 3 && !books[i].authors[j].name.empty(); j++) {
                cout << books[i].authors[j].name << ", ";
            }
            cout << endl;
            cout << "Price: $" << books[i].price << endl;
            return;
        }
    }
    cout << "Book not found." << endl;
}

void displayAllBooksInfo() {
    for (int i = 0; i < bookCount; i++) {
        cout << "Book ID: " << books[i].bookID << endl;
        cout << "ISBN: " << books[i].ISBN << endl;
        cout << "Title: " << books[i].title << endl;
        cout << "Published Year: " << books[i].publishedYear << endl;
        cout << "Authors: ";
        for (int j = 0; j < 3 && !books[i].authors[j].name.empty(); j++) {
            cout << books[i].authors[j].name << ", ";
        }
        cout << endl;
        cout << "Price: $" << books[i].price << endl;
        cout << endl;
    }
}

int main() {
    char choice;
        cout << "1. Add a book" << endl;
        cout << "2. Display book info by ISBN" << endl;
        cout << "3. Display information of all books" << endl;
        cout << "4. Exit" << endl;
        
    do {
        cout << "Enter your choise: ";
        cin >> choice;
        switch (choice) {
            case '1': {
                if (bookCount < 5) {
                    cout << "Enter book ID: ";
                    cin >> books[bookCount].bookID;
                    cout << "Enter ISBN: ";
                    cin >> books[bookCount].ISBN;
                    cout << "Enter title: ";
                    cin.ignore();
                    getline(cin, books[bookCount].title);
                    cout << "Enter published year: ";
                    cin >> books[bookCount].publishedYear;
                    cout << "Enter author names (up to 3, separate with commas): ";
                    cin.ignore();
                    string authorNames;
                    getline(cin, authorNames);
                    size_t pos = 0;
                    int authorCount = 0;
                    while ((pos = authorNames.find(',')) != string::npos && authorCount < 3) {
                        books[bookCount].authors[authorCount].name = authorNames.substr(0, pos);
                        authorNames.erase(0, pos + 1);
                        authorCount++;
                    }
                    if (!authorNames.empty() && authorCount < 3) {
                        books[bookCount].authors[authorCount].name = authorNames;
                    }
                    cout << "Enter price: ";
                    cin >> books[bookCount].price;
                    bookCount++;
                } else {
                    cout << "Cannot add more books. Array is full." << endl;
                }
                break;
            }
            case '2': {
                string ISBN;
                cout << "Enter ISBN of the book: ";
                cin >> ISBN;
                displayBookInfoByISBN(ISBN);
                break;
            }
            case '3': {
                displayAllBooksInfo();
                break;
            }
            case '4': {
                cout << "Exiting program." << endl;
                break;
            }
            default: {
                cout << "Invalid choice. Please try again." << endl;
                break;
            }
        }

    } while (choice != '4');

    return 0;
}