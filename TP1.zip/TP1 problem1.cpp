#include<iostream>
using namespace std;
int main(){
    string name;
    string major;
    char gender;
    int age;
    cout << "Enter your name:";
    cin >> name;
    cout << "Enter your gender:";
    cin >> gender;
    cout << "Enter your major:";
    cin >> major;
    cout << "Enter your age:";
    cin >> age;

    if(gender == 'M'){
        cout << "Hi, Mr."<<name<<" your age is "<<age<<" year old and you learn " << major <<"!"<<endl;
        if(age >= 18){
            cout << "You can vote" << endl;
        }else{
             cout << "You can not vote" << endl;
        }
    }else if(gender == 'F'){
        cout << "Hi, Mrs." <<name<< " you are "<<age<< "year old and you learn " << major <<"!"<<endl;
        if(age >= 18){
            cout << "You can vote." << endl;
        }else{
            cout << "You can not vote." << endl;
        }
    }
}