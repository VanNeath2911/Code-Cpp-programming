#include<iostream>
#include<cmath>
using namespace std;

void celcius_to_fahrenheit(float celcius){
    float fahrenheit = (celcius * (9/5)) + 32;
    cout <<"Temperature in fahrenheit is "<<fahrenheit<<endl;
}
void fahrenheit_to_celcius(float fahrenheit){
    float celcius = (fahrenheit - 32)*(5/9);
    cout <<"Temperature in celcius is "<<celcius<<endl;
}
void root_of_equation(float a, float b, float c){
    float delta = pow(b,b) - 4*a*c;
    if(delta > 0){
        float root1 = (-pow(b,b)+pow(delta,1/2))/2*a;
        float root2 = (-pow(b,b)-pow(delta,1/2))/2*a;
        cout <<"Root1 = "<<root1<<" and "<<"Root2 = "<<root2<<endl;
    }else if(delta == 0){
        float root = -b/(2*a);
        cout <<"Double roots "<<root<<endl;
    }else{
        cout <<"Equation has two roots are complex munber."<<endl;    
    }
}
void compute_BMI(float weight, float height){
    float BMI = weight/pow(height/100, 2);
    cout <<"BMI is "<<BMI<<endl;
    if(BMI < 18.5){
        cout <<"Underweight"<<endl;
    }else if(BMI <= 25){
        cout <<"Normal"<<endl;
    }else if(BMI <= 30){
        cout <<"Overweight"<<endl;
    }else{
        cout <<"Obese"<<endl;
    }
}
void sum_number(int n){
    int sum = 0;

    for(int i=1; i<=n; i++){
        if(i%3 != 0){
            sum = sum + i;
        }
    }
    cout <<"Summation of all munber from 1 to "<<n<<" Except those nnumbers that are divisible by 3: "<<sum<<endl;
}
int main(){
    int choice;
        cout <<"******Menu******"<<endl;
        cout <<"1. Celsius to fahrenheit."<<endl;
        cout <<"2. Fahrenheit to celsius."<<endl;
        cout <<"3. Find root of quadratic equation."<<endl;
        cout <<"4. compute BMI."<<endl;
        cout <<"5. Summation all number."<<endl;
        cout <<"6. Exit"<<endl;
    do{
        
        cout <<"Enter a number:";
        cin >> choice;
        

        switch(choice){
            case 1:{
                float celsius;
                cout << "Enter temperature in celsius:";
                cin>>celsius;
                celcius_to_fahrenheit(celsius);
                cout <<"************"<<endl;
                break;
            }
            case 2:{
                float fahrenheit;
                cout <<"Enter temperature in Fahrenheit:";
                cin>>fahrenheit;
                fahrenheit_to_celcius(fahrenheit);
                 cout <<"************"<<endl;
                break;
            }
            case 3:{
                float a,b,c;
                cout <<"Enter number a, b, c for equation ax^2+bx+c=0";
                cin>>a>>b>>c;
                root_of_equation(a, b, c);
                 cout <<"************"<<endl;
                break;
            }
            case 4:{
                float weight, height;
                cout << "Enter your weight:";
                cin>>weight;
                cout << "Enter your height:";
                cin>>height;
                compute_BMI(weight, height);
                 cout <<"************"<<endl;
                break;
            }
            case 5:{
                int n;
                cout << "Enter a number n:";
                cin>>n;
                sum_number(n);
                 cout <<"************"<<endl;
                break;
            }
            case 6:
                cout <<"Thank for using this program. Have a nice day!"<<endl;
                break;
            default:
                cout <<"Invalid number. please try again!";  
                cout <<"************"<<endl;
                break;   
        }
    }while(choice!=6);
    return 0;
}