#include<iostream>
using namespace std;
int main(){
    int minute;
    float hour;
    int second;

    cout<< "Enter minute:";
    cin>>minute;

    hour = (float)minute / 60;
    second = 60 * minute;

    cout <<minute<< " minutes equal to "<<hour<<" hour, "<<minute<<" minutes and "<<second<<" seconds."<< endl;
    return 0;
}