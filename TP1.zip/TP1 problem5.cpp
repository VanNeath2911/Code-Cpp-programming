#include<iostream>
using namespace std;
int main(){
    int sum = 0;
    int n;

    cout<< "Enter number n(number n must be bigger than 50):";
    cin>>n;

    for(int i=1; i<=n; i++){
        if(i!=10 && i!=30){
            sum = sum + i;
        }else{
            continue;
        }
    }
    cout<< "All summation from 1 to "<<n<< " is: "<<sum<<endl;
    return 0;
}