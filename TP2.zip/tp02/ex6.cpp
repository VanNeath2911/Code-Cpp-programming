#include<iostream>
using namespace std;

int getSum(){
    int num;
    cout<<"Enter a number (-1 to stop ): "; cin>>num;

    if(num== -1){
        return -1;
    }else {
        return num + getSum();
    }

}
int main(){
    int totalSum = getSum();
    cout<<"\nSummation is "<< totalSum <<endl;
}
