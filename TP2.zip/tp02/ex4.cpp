#include<iostream>
using namespace std;
int findMin(int a[], int n){
    if(n==1){
        return a[n-1];
    }

    if(findMin(a, n-1)<a[n-1]){
        return findMin(a, n-1);
    }else{
        return a[n-1];
    }

}
main(){
    int a[]={2,4,5,6,3,9,7};
    int n=7;
    cout<<"min:"<<findMin(a, n)<<endl;

}
