#include<iostream>
using namespace std;
int sum(int n){
    if(n<1){
        return 0;
    }else{
        return (n*n)+sum(n-1);
    }
}
main(){
    int n;
    while(5>2){
        cout<<"Input a number :";cin>>n;
        int total=sum(n);
        cout<<"total: "<<total<<endl;
    }

}
