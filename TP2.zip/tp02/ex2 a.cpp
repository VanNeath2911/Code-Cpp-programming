#include<iostream>
using namespace std;
int power(int m, int n){
    if(n==0){
        return 1;
    }else{
        return m*power(m,n-1);
    }
}
main(){
    int m, n;
    cout<<"Input m:";cin>>m;
    cout<<"Input n:";cin>>n;
    int total = power(m, n);
    cout<<"Total: "<<total<<endl;


}
