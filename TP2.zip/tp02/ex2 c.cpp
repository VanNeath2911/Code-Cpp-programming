#include<iostream>
using namespace std;
int digit(int n){
    if (n == 0){
        return 0;
    }else{
        return (n % 10 + digit(n / 10));
    }
}
main(){
    int num ;
    cout<<"Input a number: ";cin>>num;
    int result = digit(num);
    cout << "Sum of digits in "<< num<<" is "<<result << endl;
}

