#include <iostream>
using namespace std;
void displayStar(int n){
    if(n>0){
        cout<<"* ";
        displayStar(n-1);
    }

}
void displayNumber(int n){
    if(n>0){
        cout<<n<<" ";

        displayNumber(n-1);
    }
}
main(){
    char choice;
    int n;
    cout<<"a. A function to display n star (*)"<<endl;
    cout<<"b. Display numbers from n to 1"<<endl;

    while(n>0){
        cout<<"Input your choice: "; cin>>choice;
        cout<<"\n";
        if (choice=='a'){
            cout<<"Input a number n: "; cin >>n;
            displayStar(n);
            cout<<"\n";
        }else if (choice=='b'){
            cout<<"Input a number n: "; cin >>n;
            displayNumber(n);
            cout<<"\n";
        }
}
}
