#include<iostream>
using namespace std;
int sum(int n){
    if(n>=1){
        if(n%2!=0){
            return n+sum(n-1);
        }
        else{
            return sum(n-1);
        }
    }
}
main(){
    int n;
    while(5>2){
        cout<<"Input a number :";cin>>n;
        int total=sum(n);
        cout<<"total: "<<total<<endl;
    if(n==0){
        break;
        }
    }

}
