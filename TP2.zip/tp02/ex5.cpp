#include<iostream>
using namespace std;
int findsum(int a[], int n){
    if(n<=0){
        return 0;

    }else if(n>0){
        return findsum(a, n-1)+a[n-1];
    }
}


main(){
    int a[]={1,2,3,4,5};
    int n=5;
    cout<<"\nsum of array: "<<findsum(a, n)<<endl;
}
