#include<iostream>
using namespace std;

struct restaurant{
    string name;
    char sex;
    string phone_number;
    restaurant *next;

};
struct Queue{
    int n;
    restaurant *Front;
    restaurant *Rear;
};
Queue* emptyQueue(){
    Queue *q = new Queue;

    q->Front = NULL;
    q->Rear = NULL;
    q->n = 0;
    return q;
}
void enqueue(Queue *q, string name, char sex, string phone_number){//add to end
    restaurant *e;
    e = new restaurant;

    e->name = name;
    e->sex = sex;
    e->phone_number = phone_number;
    e->next = NULL;

    if (q->n == 0) {
        q->Front = e;
        q->Rear = e;
    } else {
        q->Rear->next = e;
        q->Rear = e;
    }
    q->n = q->n + 1;
}
void dequeue(Queue *q){
    restaurant *d;
    if(q->n == 0){
        cout<<"Cannot dequeue. Data underflow!\n";
    }else{
        d = q->Front;
        q->Front = q->Front->next;
        delete d;
        q->n = q->n--;
    }
}
void display(Queue* q) {
    restaurant* dis = q->Front;
    cout << " Name " << "\t\t" <<" Sex " << "\t"<< " Phone number" << endl;
    while (dis != NULL) {
        cout <<  dis->name << "\t\t" << dis->sex << "\t" << dis->phone_number << endl;
        dis = dis->next;
    }
    cout << "\t";
}
void displayMenu() {
    cout << "\t\tMenu:" << endl;
    cout << "1. Add a customer to the queue" << endl;
    cout << "2. Remove a customer from the queue" << endl;
    cout << "3. Display queue" << endl;
    cout << "4. Exit the program" << endl;
}
main(){
    Queue *q1 = emptyQueue();
    cout<<"Welcome to the MK Restaurant!"<<endl;
    int choice;
    while(true){
        displayMenu();
        cout<<"\t\tEnter a choice :";cin>>choice;

        if (choice == 1) {
            string name;
            char sex;
            string  phone_number;
            cout<<"Enter a student's name: ";cin>>name;
            cout<<"Enter a student's sex: ";cin>>sex;
            cout<<"Enter a student's phone number: ";cin>>phone_number;
            enqueue(q1, name, sex, phone_number);
            cout<<"\n*******************************"<<endl;
        } else if (choice == 2) {
            cout<<"Serving Customer, "<<q1->Front->name<<"!"<<endl;
            dequeue(q1);

        } else if (choice == 3) {
            display(q1);

        } else if (choice == 4) {
            cout << "Exiting the program." << endl;
            break;
        } else {
            cout << "Invalid choice. Please try again." << endl;
        }
    }
}