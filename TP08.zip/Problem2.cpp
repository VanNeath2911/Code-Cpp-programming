#include<iostream>
using namespace std;
struct Element{
    string name, department, university;
    int age, ID, year;
    char gender;
    Element *next;
}; 
struct Queue{
    int n;
    Element *rear;
    Element *fron;
}; 
int main(){
    
}