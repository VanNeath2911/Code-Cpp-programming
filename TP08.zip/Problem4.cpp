#include"MyQueue.h"
int main(){
    Queue *L1;
    L1 = createEmptyQueue();
    cout << "All data in queue: " << endl;
    Enqueue(L1, "OP007");
    Enqueue(L1, "OP005");
    Enqueue(L1, "OP020");
    Enqueue(L1, "OP111");
    Enqueue(L1, "OP777");
    Display(L1);
    cout << "Data in queue after delet: " << endl;
    Dequeue(L1);
    Display(L1);
    cout << "Search data in queue: " << endl;
    SearchData(L1, "D");
}