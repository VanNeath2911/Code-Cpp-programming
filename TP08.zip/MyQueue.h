#include<iostream>
using namespace std;
struct Element{
    string ID;
    Element *next;
};
struct Queue{
    int n;
    Element *rear;
    Element *front;
};
Queue *createEmptyQueue(){
    Queue *myqueue;
    myqueue = new Queue;
    myqueue -> n = 0;
    myqueue -> rear = NULL;
    myqueue -> front = NULL;
    return myqueue;
}
void Enqueue(Queue *myqueue, string ID){
    Element *e;
    e = new Element;
    e -> next = NULL;
    e -> ID = ID;
    if(myqueue -> n == 0){
        myqueue  -> front = e;
        myqueue -> rear = e;
        myqueue -> n++;
    }else{
        myqueue -> rear -> next = e;
        myqueue -> rear = e;
        myqueue -> n++;
    }
}
void Dequeue(Queue *myqueue){
    if(myqueue -> n == 0){
        cout << "Can not delete since queue is empty. \n" << endl;
    }else{
        Element *t;
        t = myqueue -> front;
        myqueue ->front = myqueue -> front -> next;
        delete t;
        myqueue -> n--;
    }
}
void Display(Queue *tmp){
    Element *ls;
    ls = tmp -> front;
    while(ls != NULL){
        cout << ls -> ID << " " << endl;
        ls = ls -> next ;
    }
}
void SearchData(Queue *myqueue, string D){
    cout << "Enter to search: ";
    cin >> D;
    Element *tmp = myqueue -> front;
    int count = 0;
    while(tmp != NULL){
        if(tmp -> ID == D){
            cout << "Found! " << endl;
            count++;
            break;
        }
        tmp = tmp -> next;
    }if(count == 0){
        cout << "Not found." << endl;
    }
}