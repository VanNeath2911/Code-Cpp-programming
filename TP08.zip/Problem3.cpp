#include<iostream>
using namespace std;
struct Element{
    string ID;
    Element *next;
};
struct Queue{
    int n;
    Element *rear;
    Element *front;
};
Queue *createEmptyQueue(){
    Queue *myqueue;
    myqueue = new Queue;
    myqueue -> n = 0;
    myqueue -> rear = NULL;
    myqueue -> front = NULL;
    return myqueue;
}
void Enqueue(Queue *s, string ID){
    Element *e;
    e = new Element;
    e -> next = NULL;
    e -> ID = ID;
    if(s -> n == 0){
        s -> front = e;
        s -> rear = e;
        s -> n++;
    }else{
        s -> rear -> next = e;
        s -> rear = e;
        s -> n++;
    }
}
void Display(Queue *tmp){
    Element *ls;
    ls = tmp -> front;
    while(ls != NULL){
        cout << ls -> ID << " " << endl;
        ls = ls -> next ;
    }
}
int main(){
    Queue *L1;
    L1 = createEmptyQueue();
    Enqueue(L1, "OP007");
    Enqueue(L1, "OP005");
    Enqueue(L1, "OP020");
    Enqueue(L1, "OP111");
    Enqueue(L1, "OP777");
    Display(L1);
}