#include<iostream>
using namespace std;
struct element{
    string letter;
    element *next;
};
struct Queue{
    element *rear, *front;
    int n;
};
Queue *createQueue(){
    Queue *myQueue;
    myQueue = new Queue;
    myQueue -> n =0;
    myQueue -> front = NULL;
    myQueue -> rear = NULL;
    return myQueue;
}
void enqueue (Queue *myQueue,string newdata){
    //create new element
    element *e;
    e = new element;
    e-> letter = newdata;
    e -> next = NULL;   
    if(myQueue-> n==0){
        myQueue -> rear = e;
        myQueue -> front =e;
        myQueue -> n++;
    }else{
        myQueue -> rear -> next = e;
        myQueue -> rear = e;
        myQueue -> n++;
    }
}
void deQueue(Queue *myQueue){
    if(myQueue -> n ==0){
        cout<<"You can't delete since this queue is empty!!"<<endl;
    }else{
        element *t = myQueue -> front;
        cout << "Doing task " << t -> letter << " Done..." << endl;
        cout << endl;
        myQueue -> front = myQueue-> front -> next;
        delete t; 
        myQueue -> n--;

    }
}
void readQueue(Queue *q){
    element *t;
    t = q -> front;
    while(t!=NULL){
        cout << t -> letter <<" ";
        t = t-> next;
    }
}
int main(){
    Queue *Q;
    Q = createQueue();
    string choice;
    int count = 0;
    enqueue(Q,"Task 4");
    enqueue(Q,"Task 1");
    enqueue(Q,"Task 2");
    enqueue(Q,"Task 3");
    cout << endl;
    cout << "Task4 " << "Task1 " << "Task2 " << "Task3 " << endl;
    while(1){
        cout<<"Do you want to activate a task in your queue now ? ";cin>>choice;
        if(choice=="yes"){
            deQueue(Q);
            readQueue(Q);
            if(count == 4){
                break;
                cout << "The task is empty." << endl;
            }
            cout<<endl;
            count ++;
        }
        else{
            cout<<"why u did too late.\n"<<endl;
        }
    }
}