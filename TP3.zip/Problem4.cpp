#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int main(){
    string folder = "C:/Users/USER/Desktop/IT/GTR S2/TP/File 10/1000files";
    for(int i = 1; i <= 1000; i++){
        string filename = folder + "file" + to_string(i) + ".txt";
        ofstream outfile;
        outfile.open(filename);
        for(int j =i; j <=10*i; j++){
            outfile << j << " ";
        }
        outfile.close();
    }
return 0;
}