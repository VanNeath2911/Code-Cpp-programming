#include<iostream>
#include<fstream>
using namespace std;

struct Student{
	string name;
	string gmail;
	int age;
};
int main(){
	Student student[100];
	
	fstream Readfile;
	Readfile.open("data.txt", ios::in);
	int index = 0;
	while(!Readfile.eof()){
		Readfile >> student[index].name;
		Readfile >> student[index].age;
		Readfile >> student[index].gmail;
		
		cout << student[index].name << "\t" << student[index].age << "\t" << student[index].gmail << endl;
		index ++;
	}
	return 0;
} 
