#include<iostream>
#include<fstream>
#include<cstdlib>

using namespace std;

int main(){
	fstream myfile;
	int numbers;
	myfile.open("myluckynumber.txt", ios::out);
	for(int i=1; i<=150; i++){
		cout<< rand() << " ";
		numbers = rand() % 1000;		
		myfile<< numbers << " ";	
	}
	cout << "\n\t";
		
	myfile.close();
	int number;
	fstream Readfile;
	Readfile.open("myluckynumber.txt", ios::in);
	while(!Readfile.eof()){
		Readfile >> numbers;
		cout << numbers << " ";
		
	}
	cout << "\n";
	return 0;
}
