#include<iostream>
#include<fstream>
using namespace std;

struct Student{
    string name[100];
    string gmail[100];
    int ID[100];
};
Student student;
int numberstudent = 0;

void displaydata(){
    for(int i = 0; i < numberstudent; i++){
        cout << "ID: " << student.ID[i] << ", Name: " << student.name[i] << ", Email: " << student.gmail[i] << endl; 
    }
}

void addinformation(){
    for(int i = 0; i < 3; i++){
        cout << "Enter student ID: " << numberstudent + 1 << ": ";
        cin >> student.ID[numberstudent];
        cout << "Enter student name: " << numberstudent + 1 << ": ";
        cin >> student.name[numberstudent];
        cout << "Enter student email: " << numberstudent + 1 << ": ";
        cin >> student.gmail[numberstudent];
        numberstudent ++;
    }
}

void SearchEmail(){
    string SearchEmail;
    cout << "Enter student's email: ";
    cin >> SearchEmail;

    bool found = false;
    for(int i = 0; i < numberstudent; i ++){
        if(student.gmail[i] == SearchEmail){
            cout << "ID: " << student.ID[i] << ", Name: " << student.name[i] << ", Gmail " << student.gmail[i] << endl;
            found = true;
            break; 
        } 
    }
    if(!found){
    cout << "No data." << endl;
    }
}

void InputStudentInfotoFile(){
    ofstream InputFile;
    InputFile.open("StudentInfo.txt", ios::out);
    for(int i = 0; i < numberstudent; i++){
        InputFile << student.ID[i] << " " << student.name[i] << " " << " " << student.gmail[i] << endl;
    }
    InputFile.close();
    cout << "Data written to file." << endl;
}

void UpdateStudentInfo(){
    int updateID;
    cout << "Enter student ID for update:";
    cin >> updateID;
    bool found = false;
    for(int i = 0; i < numberstudent; i++){
        if(student.ID[i] == updateID){
            cout << "Enter new name of student: " << student.name[i] << ": ";
            cin.ignore();
            getline(cin, student.name[i]);
            cout << "Enter new gmail of student: " << student.gmail[i] << ": ";
            getline(cin , student.name[i]);
            found = true;
            break;
        }
    }
    if(!found){
        cout << "Student not found." << endl;
    }
}

int main(){
    char choice;
        cout << "Menu:" << endl;
        cout << "A. Display the data from array." << endl;
        cout << "B. Add information of 3 more students." << endl;
        cout << "C. Search for a student based on an email address." << endl;
        cout << "D. Write student information in the array to file." << endl;
        cout << "E. Update a student information based on ID." << endl;
        cout << "F. Exit program." << endl;
    while(1){
        
        cout << "\nEnter choice: ";
        cin >> choice;
        cout << "\n";

        if(choice == 'A'){
            displaydata();
        }
        if(choice == 'B'){
            addinformation();
        }
        if(choice == 'C'){
            SearchEmail();
        }
        if(choice == 'D'){
            InputStudentInfotoFile();
        }
        if(choice == 'E'){
            UpdateStudentInfo();
        }
        if(choice == 'F'){
            cout << "Exit program." << endl;
            break;
        }
    }
    return 0;
}



